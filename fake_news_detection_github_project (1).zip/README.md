# Fake News Detection System

A Python machine-learning project that classifies a supplied news headline or article as **REAL** or **FAKE** using TF-IDF text features and Logistic Regression. It includes a Streamlit web interface.

## Features
- Paste a headline or article for analysis.
- Predict REAL or FAKE.
- Show the model's estimated class confidence.
- Display a holdout accuracy metric.
- Explore and preview the example dataset.
- Download an individual analysis as CSV.
- Train the model from the command line.

## Project structure
```text
fake_news_detection/
├── app.py
├── model_utils.py
├── train_model.py
├── news_dataset.csv
├── requirements.txt
├── README.md
├── .gitignore
└── models/                  # Generated locally when trained
```

## Requirements
- Python 3.9+
- VS Code or another Python IDE
- Internet access to install dependencies

## Run locally

### 1. Clone your GitHub repository
```bash
git clone https://github.com/YOUR-USERNAME/fake-news-detection.git
cd fake-news-detection
```

### 2. Create and activate a virtual environment
Windows:
```bash
python -m venv .venv
.venv\\Scripts\\activate
```
macOS/Linux:
```bash
python3 -m venv .venv
source .venv/bin/activate
```

### 3. Install dependencies
```bash
pip install -r requirements.txt
```

### 4. Train the model (optional)
```bash
python train_model.py
```
The Streamlit app can also train the model automatically the first time it runs.

### 5. Launch the app
```bash
streamlit run app.py
```
Open the local address printed in the terminal, usually http://localhost:8501.

## Dataset format
`news_dataset.csv` must contain these columns:
| Column | Description |
|---|---|
| text | News headline or article text |
| label | `REAL` or `FAKE` |

To use another dataset, keep these column names or update `model_utils.py`. Ensure labels are consistently formatted.

## Important dataset and accuracy notice
The included CSV is a **small synthetic demonstration dataset**, not a verified collection of real and fake news stories. It is designed to demonstrate the end-to-end coding workflow only. The model can learn superficial wording patterns and may perform poorly on real-world news. Its displayed confidence is not the probability that a claim is true, and its accuracy score does not establish fact-checking ability.

For a meaningful project evaluation, replace the sample CSV with a reputable, appropriately licensed, well-documented dataset; inspect label quality; avoid duplicate or near-duplicate leakage across train/test splits; evaluate on newer unseen articles; and compare precision, recall, F1-score and confusion matrices. A model prediction must never be treated as proof that a story is true or false. Verify claims against multiple reliable sources.

## Upload to GitHub
Create an empty repository named `fake-news-detection`, then run:
```bash
git init
git add .
git commit -m "Add fake news detection project"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/fake-news-detection.git
git push -u origin main
```
Replace `YOUR-USERNAME` with your GitHub username.

## Future improvements
- Use a larger, verified news dataset.
- Add confusion matrix and precision/recall/F1 reporting.
- Compare Logistic Regression, Naive Bayes and Linear SVM.
- Add source links and a manual verification workflow.
- Add multilingual text preprocessing and robust validation.
