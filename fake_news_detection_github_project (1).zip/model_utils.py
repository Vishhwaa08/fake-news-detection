from pathlib import Path
import joblib
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.metrics import accuracy_score, classification_report

TEXT_COLUMN = "text"
LABEL_COLUMN = "label"
VALID_LABELS = {"REAL", "FAKE"}

def load_dataset(path):
    df = pd.read_csv(path)
    missing = {TEXT_COLUMN, LABEL_COLUMN} - set(df.columns)
    if missing:
        raise ValueError(f"Dataset must contain columns: {', '.join(sorted(missing))}")
    df = df[[TEXT_COLUMN, LABEL_COLUMN]].dropna()
    df[TEXT_COLUMN] = df[TEXT_COLUMN].astype(str).str.strip()
    df[LABEL_COLUMN] = df[LABEL_COLUMN].astype(str).str.upper().str.strip()
    df = df[(df[TEXT_COLUMN] != "") & df[LABEL_COLUMN].isin(VALID_LABELS)]
    if df[LABEL_COLUMN].nunique() != 2 or len(df) < 10:
        raise ValueError("Dataset needs at least 10 rows and both REAL and FAKE labels.")
    return df

def train_model(df):
    X_train, X_test, y_train, y_test = train_test_split(
        df[TEXT_COLUMN], df[LABEL_COLUMN],
        test_size=0.25, random_state=42, stratify=df[LABEL_COLUMN]
    )
    model = Pipeline([
        ("tfidf", TfidfVectorizer(
            lowercase=True, stop_words="english",
            ngram_range=(1, 2), max_features=20000,
            sublinear_tf=True
        )),
        ("classifier", LogisticRegression(max_iter=1000, class_weight="balanced"))
    ])
    model.fit(X_train, y_train)
    predictions = model.predict(X_test)
    metrics = {
        "accuracy": float(accuracy_score(y_test, predictions)),
        "report": classification_report(y_test, predictions, output_dict=True, zero_division=0),
        "test_size": int(len(y_test)),
    }
    return model, metrics

def load_or_train_model(dataset_path, model_path):
    dataset_path, model_path = Path(dataset_path), Path(model_path)
    df = load_dataset(dataset_path)
    if model_path.exists() and model_path.stat().st_mtime >= dataset_path.stat().st_mtime:
        bundle = joblib.load(model_path)
        return bundle["model"], bundle["metrics"], len(df)
    model, metrics = train_model(df)
    model_path.parent.mkdir(parents=True, exist_ok=True)
    joblib.dump({"model": model, "metrics": metrics}, model_path)
    return model, metrics, len(df)

def predict_news(model, text):
    if not text or not text.strip():
        raise ValueError("Please enter a news article or headline.")
    prediction = model.predict([text.strip()])[0]
    probabilities = model.predict_proba([text.strip()])[0]
    classes = list(model.classes_)
    confidence = float(probabilities[classes.index(prediction)])
    return prediction, confidence
