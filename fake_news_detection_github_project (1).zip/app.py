from pathlib import Path
import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
from model_utils import load_or_train_model, predict_news, load_dataset

st.set_page_config(page_title="Fake News Detection", page_icon="📰", layout="wide")
ROOT = Path(__file__).resolve().parent
DATA_PATH = ROOT / "news_dataset.csv"
MODEL_PATH = ROOT / "models" / "fake_news_model.joblib"

st.title("📰 Fake News Detection System")
st.write("A text-classification demo that analyzes a headline or article using TF-IDF and Logistic Regression.")

@st.cache_resource
def get_model():
    return load_or_train_model(DATA_PATH, MODEL_PATH)

try:
    model, metrics, row_count = get_model()
    data = load_dataset(DATA_PATH)
except Exception as exc:
    st.error(f"Could not load dataset/model: {exc}")
    st.stop()

with st.sidebar:
    st.header("Model information")
    st.metric("Dataset rows", row_count)
    st.metric("Holdout accuracy", f"{metrics['accuracy']:.1%}")
    st.caption("This metric is from a small illustrative sample and is not a measure of real-world reliability.")

st.subheader("Analyze a news item")
news_text = st.text_area(
    "Paste a headline or article",
    height=180,
    placeholder="Enter the news text you want to analyze..."
)
if st.button("Analyze news", type="primary"):
    if not news_text.strip():
        st.warning("Please enter some text first.")
    else:
        try:
            label, confidence = predict_news(model, news_text)
            if label == "REAL":
                st.success(f"Model prediction: {label}")
            else:
                st.error(f"Model prediction: {label}")
            st.metric("Model confidence", f"{confidence:.1%}")
            st.warning(
                "This is an automated text-pattern prediction, not a fact-check. "
                "Verify important claims with multiple reliable sources."
            )
            st.session_state["last_result"] = {
                "text": news_text, "prediction": label, "model_confidence": round(confidence, 4)
            }
        except Exception as exc:
            st.error(str(exc))

if "last_result" in st.session_state:
    result_df = pd.DataFrame([st.session_state["last_result"]])
    st.download_button(
        "Download analysis as CSV",
        result_df.to_csv(index=False),
        file_name="news_analysis.csv",
        mime="text/csv"
    )

st.divider()
st.subheader("Explore the demonstration dataset")
counts = data["label"].value_counts()
fig, ax = plt.subplots()
ax.bar(counts.index, counts.values)
ax.set_ylabel("Number of examples")
ax.set_title("Dataset label distribution")
st.pyplot(fig)
plt.close(fig)

with st.expander("Preview dataset"):
    st.dataframe(data.head(20), use_container_width=True)
    st.caption("The included examples are synthetic and intended only to demonstrate the workflow.")
