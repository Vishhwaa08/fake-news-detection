from pathlib import Path
import json
import joblib
from model_utils import load_dataset, train_model

ROOT = Path(__file__).resolve().parent

def main():
    data = load_dataset(ROOT / "news_dataset.csv")
    model, metrics = train_model(data)
    model_dir = ROOT / "models"
    model_dir.mkdir(exist_ok=True)
    joblib.dump({"model": model, "metrics": metrics}, model_dir / "fake_news_model.joblib")
    (model_dir / "metrics.json").write_text(json.dumps(metrics, indent=2), encoding="utf-8")
    print(f"Training rows: {len(data)}")
    print(f"Holdout accuracy: {metrics['accuracy']:.3f}")
    print(f"Model saved in: {model_dir}")

if __name__ == "__main__":
    main()
